package org.jfree.data.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	DataUtilitiesTest.class,
	RangeTest.class
})
public class JunitTestSuite {

}
